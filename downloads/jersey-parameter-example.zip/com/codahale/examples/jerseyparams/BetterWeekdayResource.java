package com.codahale.examples.jerseyparams;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

@Path("/v3/weekday/{date}")
@Produces(MediaType.TEXT_PLAIN)
public class BetterWeekdayResource {
	private static final DateTimeFormatter ISO_BASIC = ISODateTimeFormat.basicDate();
	
	@GET
	public String getWeekday(@PathParam("date") String dateAsString) {
		try {
			final DateTime date = ISO_BASIC.parseDateTime(dateAsString);
			return dateAsString + " is on a " + date.dayOfWeek().getAsText() + ".";
		} catch (IllegalArgumentException e) {
			throw new WebApplicationException(
				Response
					.status(Status.BAD_REQUEST)
					.entity("Couldn't parse date: " + dateAsString + " (" + e.getMessage() + ")")
					.build()
			);
		}
	}
}
