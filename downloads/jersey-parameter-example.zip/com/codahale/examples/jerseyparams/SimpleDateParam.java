package com.codahale.examples.jerseyparams;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

public class SimpleDateParam {
	private static final DateTimeFormatter ISO_BASIC = ISODateTimeFormat.basicDate();
	private final DateTime date;
	private final String originalValue;
	
	public SimpleDateParam(String date) throws WebApplicationException {
		try {
			this.originalValue = date;
			this.date = ISO_BASIC.parseDateTime(date);
		} catch (IllegalArgumentException e) {
			throw new WebApplicationException(
				Response
					.status(Status.BAD_REQUEST)
					.entity("Couldn't parse date: " + date + " (" + e.getMessage() + ")")
					.build()
			);
		}
	}
	
	public DateTime getDate() {
		return date;
	}
	
	public String getOriginalValue() {
		return originalValue;
	}
}
