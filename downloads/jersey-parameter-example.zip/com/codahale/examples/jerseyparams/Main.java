package com.codahale.examples.jerseyparams;

import javax.servlet.Servlet;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.bio.SocketConnector;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.servlet.Context;
import org.mortbay.jetty.servlet.ServletHolder;

import com.sun.jersey.spi.container.servlet.ServletContainer;

public class Main {
	public static void main(String[] args) throws Exception {
		final Server server = new Server();
		final Connector connector = new SocketConnector();
		connector.setPort(8080);
		server.addConnector(connector);
		
		final Servlet servlet = new ServletContainer();
		final ServletHolder servletHolder = new ServletHolder(servlet);
		servletHolder.setInitParameter(
			"com.sun.jersey.config.property.packages",
			"com.codahale.examples.jerseyparams"
		);
		
		final Context root = new Context(server, "/");
		root.addServlet(servletHolder, "/*");

		server.start();
		server.join();
	}
}
