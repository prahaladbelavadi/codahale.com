package com.codahale.examples.jerseyparams;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

@Path("/v2/weekday/{date}")
@Produces(MediaType.TEXT_PLAIN)
public class NaiveWeekdayResource {
	private static final DateTimeFormatter ISO_BASIC = ISODateTimeFormat.basicDate();
	
	@GET
	public String getWeekday(@PathParam("date") String dateAsString) {
		final DateTime date = ISO_BASIC.parseDateTime(dateAsString);
		return dateAsString + " is on a " + date.dayOfWeek().getAsText() + ".";
	}
}
