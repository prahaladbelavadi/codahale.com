package com.codahale.examples.jerseyparams;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/v5/weekday/{date}")
@Produces(MediaType.TEXT_PLAIN)
public class FinalWeekdayResource {
	@GET
	public String getWeekday(@PathParam("date") DateParam dateParam) {
		return dateParam.getOriginalParam()
				+ " is on a "
				+ dateParam.getValue().dayOfWeek().getAsText()
				+ ".";
	}
}
