package com.codahale.examples.jerseyparams;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/v1/weekday/{date}")
@Produces(MediaType.TEXT_PLAIN)
public class SkeletonWeekdayResource {
	@GET
	public String getWeekday(@PathParam("date") String date) {
		return date + " is on a ???.";
	}
}
