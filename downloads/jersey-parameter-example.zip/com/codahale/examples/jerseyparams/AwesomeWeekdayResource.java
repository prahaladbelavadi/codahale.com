package com.codahale.examples.jerseyparams;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/v4/weekday/{date}")
@Produces(MediaType.TEXT_PLAIN)
public class AwesomeWeekdayResource {
	@GET
	public String getWeekday(@PathParam("date") SimpleDateParam dateParam) {
		return dateParam.getOriginalValue()
				+ " is on a "
				+ dateParam.getDate().dayOfWeek().getAsText()
				+ ".";
	}
}